1. The following packages are needed:
	numpy 
	sys
	matplotlib
	os
	sklearn

2. I am using jupyter notebook for all my code. You need to use the command 'jupyter notebook' from the terminal in order to open the jupyter notebook. After that change the path in np.loadtxt('_________') wherever the binclass.txt and binclassv2.txt files are stored. After that run the notebook. For sake of simplicity I am also including the pdf version of my notebooks.
